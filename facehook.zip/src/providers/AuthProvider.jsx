// import { useState } from "react";
// import { AuthContext } from "../context";

// const AuthProvider = ({ children }) => {
//   const [auth, setAuth] = useState({});
//   return (
//     <AuthContext.Provider value={{ auth, setAuth }}>
//       {children}
//     </AuthContext.Provider>
//   );
// };

// export default AuthProvider;

// src/providers/AuthProvider.jsx (assuming this path)
import { useState } from "react";

import { AuthContext } from "../context";

const AuthProvider = ({ children }) => {
  const [auth, setAuth] = useState({});

  // This logout only clears state, it doesn't navigate directly
  const logout = () => {
    setAuth({}); // Clear the auth state completely
    // If you persist tokens in localStorage/sessionStorage, clear them here too:
    // localStorage.removeItem("authToken");
    // localStorage.removeItem("refreshToken");
    // localStorage.removeItem("user");
    console.log("Auth state cleared by AuthProvider.");
  };

  return (
    <AuthContext.Provider value={{ auth, setAuth, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export default AuthProvider;
