const NotFoundPage = () => {
  return <div className="text-center font-bold">Page Not Found</div>;
};

export default NotFoundPage;
