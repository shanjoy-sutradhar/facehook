const RegistrationPage = () => {
  return <div>Registration Page</div>;
};

export default RegistrationPage;
