function ProfileImage() {
  return <div>Image</div>;
}

export default ProfileImage;
