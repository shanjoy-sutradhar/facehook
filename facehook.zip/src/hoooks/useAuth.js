// import { useContext, useDebugValue } from "react";
// import { AuthContext } from "../context";

// export const useAuth = () => {
//   const { auth } = useContext(AuthContext);
//   useDebugValue(auth, (auth) =>
//     auth?.user ? "User Logged in" : "User Logged out"
//   );
//   return useContext(AuthContext);
// };

// src/hoooks/useAuth.js (assuming this path)
import { useContext, useDebugValue } from "react";
import { AuthContext } from "../context"; // Correct path to AuthContext

export const useAuth = () => {
  const context = useContext(AuthContext);
  useDebugValue(context.auth, (auth) =>
    auth?.user ? "User Logged in" : "User Logged out"
  );
  return context; // Returns { auth, setAuth, logout }
};
