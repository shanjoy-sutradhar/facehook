import { createContext } from "react";

const AuthContext = createContext(null);
const ProfileContext = createContext();

export { AuthContext, ProfileContext };
