const MyPosts = () => {
  return <div>My Posts</div>;
};

export default MyPosts;
