// import axios from "axios";
// import { useEffect } from "react";
// import { api } from "../api";
// import { useAuth } from "./useAuth";
// const useAxios = () => {
//   const { auth, setAuth } = useAuth();
//   useEffect(() => {
//     //Add a request intercepter
//     const requestIntercept = api.interceptors.request.use(
//       (config) => {
//         const authToken = auth?.authToken;
//         if (authToken) {
//           config.headers.Authorization = `Bearer ${authToken}`;
//         }
//         return config;
//       },
//       (error) => Promise.reject(error)
//     );

//     //add a response intercepter
//     const responseIntercept = api.interceptors.response.use(
//       (response) => response,
//       async (error) => {
//         const originalRequest = error.config;
//         if (error.response.status === 401 && !originalRequest._retry) {
//           originalRequest._retry = true;
//           try {
//             const refreshToken = auth?.refreshToken;
//             const response = await axios.post(
//               `${import.meta.env.VITE_SERVER_BASE_URL}/auth/refresh-token`,
//               { refreshToken }
//             );
//             const { token } = response.data;
//             console.log(`New Token:${token}`);
//             setAuth({ ...auth, authToken: token });
//             originalRequest.headers.Authorization = `Bearer ${token}`;
//             return axios(originalRequest);
//           } catch (error) {
//             console.log(error);
//             throw error;
//           }
//         }
//         return Promise.reject(error);
//       }
//     );

//     return () => {
//       api.interceptors.request.eject(requestIntercept);
//       api.interceptors.response.eject(responseIntercept);
//     };
//   }, [auth.authToken]);
//   return { api };
// };

// export default useAxios;

// src/hoooks/useAxios.js (assuming this path)
import axios from "axios";
import { useEffect } from "react";
import { api } from "../api"; // Make sure this `api` is your axios instance
import { useAuth } from "./useAuth"; // Adjust path if needed

const useAxios = () => {
  const { auth, setAuth, logout } = useAuth(); // Get logout from useAuth

  useEffect(() => {
    // Request Interceptor: Adds auth token to outgoing requests
    const requestIntercept = api.interceptors.request.use(
      (config) => {
        const authToken = auth?.authToken;
        if (authToken) {
          config.headers.Authorization = `Bearer ${authToken}`;
        }
        return config;
      },
      (error) => Promise.reject(error)
    );

    // Response Interceptor: Handles 401 errors for token refresh
    const responseIntercept = api.interceptors.response.use(
      (response) => response,
      async (error) => {
        const originalRequest = error.config;

        // Condition 1: If the refresh token request itself fails with a 401
        // This prevents an infinite loop if the refresh token is truly invalid/expired.
        // Make sure `error.response` exists before accessing `.status`
        if (
          error.response?.status === 401 &&
          originalRequest.url.includes("/auth/refresh-token")
        ) {
          console.error(
            "Refresh token request failed with 401. User session invalid. Performing logout."
          );
          logout(); // Clear authentication state
          return Promise.reject(error); // Reject the promise to stop further processing
        }

        // Condition 2: If another request fails with a 401 and hasn't been retried yet
        if (error.response?.status === 401 && !originalRequest._retry) {
          originalRequest._retry = true; // Mark the request as retried
          try {
            const refreshToken = auth?.refreshToken;

            // If no refresh token is available, we cannot proceed. Log out.
            if (!refreshToken) {
              console.error(
                "No refresh token available to retry request. Performing logout."
              );
              logout(); // Clear authentication state
              return Promise.reject(new Error("No refresh token available."));
            }

            // Attempt to get a new access token using the refresh token
            const refreshResponse = await axios.post(
              `${import.meta.env.VITE_SERVER_BASE_URL}/auth/refresh-token`,
              { refreshToken }
            );

            const { token } = refreshResponse.data;
            console.log(`New Access Token acquired: ${token}`);

            // Update the authentication state with the new access token
            setAuth({ ...auth, authToken: token });

            // Update the original request's authorization header with the new token
            originalRequest.headers.Authorization = `Bearer ${token}`;

            // Retry the original failed request with the new access token
            return axios(originalRequest);
          } catch (refreshError) {
            // This block executes if the refresh token request itself failed
            console.error(
              "Critical: Token refresh failed in interceptor:",
              refreshError
            );
            logout(); // Crucially, clear auth state and trigger logout if refresh fails
            return Promise.reject(refreshError); // Propagate the error so the original call also fails
          }
        }
        // For any other errors (not 401, or already retried 401), just reject
        return Promise.reject(error);
      }
    );

    // Cleanup function: Eject interceptors when component unmounts
    return () => {
      api.interceptors.request.eject(requestIntercept);
      api.interceptors.response.eject(responseIntercept);
    };
  }, [auth.authToken, logout]); // Dependencies for useEffect: Re-run if authToken or logout changes

  return { api }; // Return the configured axios instance
};

export default useAxios;
